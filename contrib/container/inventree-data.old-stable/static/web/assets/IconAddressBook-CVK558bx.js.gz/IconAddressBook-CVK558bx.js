import{t as a}from"./index-B7aS2nJw.js";/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["path",{d:"M20 6v12a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2",key:"svg-0"}],["path",{d:"M10 16h6",key:"svg-1"}],["path",{d:"M11 11a2 2 0 1 0 4 0a2 2 0 1 0 -4 0",key:"svg-2"}],["path",{d:"M4 8h3",key:"svg-3"}],["path",{d:"M4 12h3",key:"svg-4"}],["path",{d:"M4 16h3",key:"svg-5"}]],s=a("outline","address-book","AddressBook",o);export{s as I};
//# sourceMappingURL=IconAddressBook-CVK558bx.js.map
