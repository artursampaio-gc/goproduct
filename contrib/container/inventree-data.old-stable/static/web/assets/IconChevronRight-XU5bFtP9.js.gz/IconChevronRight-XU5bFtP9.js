import{t as o}from"./index-B7aS2nJw.js";/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["path",{d:"M9 6l6 6l-6 6",key:"svg-0"}]],n=o("outline","chevron-right","ChevronRight",t);export{n as I};
//# sourceMappingURL=IconChevronRight-XU5bFtP9.js.map
