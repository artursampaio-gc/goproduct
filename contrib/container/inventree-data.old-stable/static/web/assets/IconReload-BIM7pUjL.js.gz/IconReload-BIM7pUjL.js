import{t as o}from"./index-B7aS2nJw.js";/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M19.933 13.041a8 8 0 1 1 -9.925 -8.788c3.899 -1 7.935 1.007 9.425 4.747",key:"svg-0"}],["path",{d:"M20 4v5h-5",key:"svg-1"}]],a=o("outline","reload","Reload",e);export{a as I};
//# sourceMappingURL=IconReload-BIM7pUjL.js.map
